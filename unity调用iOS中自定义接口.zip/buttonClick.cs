using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Runtime.InteropServices;

public class buttonClick : MonoBehaviour {
	[DllImport("__Internal")]
	private static extern void changeToVoice(string a,float rate,float volume);

	public InputField shuru;
	public InputField rate;
	public InputField volume;

	private float rateNum;
	private float volumeNum;

	// Use this for initialization
	void Start () {
	
	}
	// Update is called once per frame
	void Update () {

	}
	//
	public void resultFromiOS(string result){

		shuru.text = result;
	}

	public void Click()
	{
		Debug.Log (rate.text + volume.text);

		if (rate.text !="") {
			rateNum = float.Parse (rate.text);
		} else {
			rateNum = 0.5f;
		}

		if (volume.text !="") {
			volumeNum = float.Parse (volume.text);
		} else {
			volumeNum = 0.7f;
		}

		changeToVoice (shuru.text,rateNum,volumeNum);
	}


}
